--
-- PostgreSQL database dump
--

\restrict FnAQRsImaNaFpgJLFaSZqpcTgXeeLoWrufDDxkrbhhwqzV65ZLQPjkL9PUARds2

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: ConfirmationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ConfirmationStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'UNAVAILABLE'
);


ALTER TYPE public."ConfirmationStatus" OWNER TO postgres;

--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'EMAIL',
    'WHATSAPP',
    'EMAIL_WHATSAPP',
    'BOTH'
);


ALTER TYPE public."NotificationChannel" OWNER TO postgres;

--
-- Name: NotificationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationStatus" AS ENUM (
    'SENT',
    'FAILED',
    'PENDING'
);


ALTER TYPE public."NotificationStatus" OWNER TO postgres;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationType" AS ENUM (
    'SCHEDULE_ASSIGNMENT',
    'SCHEDULE_UPDATE',
    'SCHEDULE_CANCELLATION',
    'SCHEDULE_REMINDER',
    'SCHEDULE_CONFIRMATION',
    'SCHEDULE_CONFIRMATION_REMINDER',
    'CUSTOM_NOTIFICATION'
);


ALTER TYPE public."NotificationType" OWNER TO postgres;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MEMBER'
);


ALTER TYPE public."UserRole" OWNER TO postgres;

--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserStatus" AS ENUM (
    'PENDING',
    'ACTIVE',
    'INACTIVE',
    'REJECTED'
);


ALTER TYPE public."UserStatus" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action text NOT NULL,
    "targetId" integer,
    "userId" integer,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: campuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campuses (
    id integer NOT NULL,
    name text NOT NULL,
    city text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.campuses OWNER TO postgres;

--
-- Name: campuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.campuses_id_seq OWNER TO postgres;

--
-- Name: campuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campuses_id_seq OWNED BY public.campuses.id;


--
-- Name: function_group_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.function_group_admins (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "functionGroupId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.function_group_admins OWNER TO postgres;

--
-- Name: function_group_admins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.function_group_admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.function_group_admins_id_seq OWNER TO postgres;

--
-- Name: function_group_admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.function_group_admins_id_seq OWNED BY public.function_group_admins.id;


--
-- Name: function_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.function_groups (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "ministryId" integer
);


ALTER TABLE public.function_groups OWNER TO postgres;

--
-- Name: function_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.function_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.function_groups_id_seq OWNER TO postgres;

--
-- Name: function_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.function_groups_id_seq OWNED BY public.function_groups.id;


--
-- Name: functions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.functions (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    active boolean DEFAULT true NOT NULL,
    "groupId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.functions OWNER TO postgres;

--
-- Name: functions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.functions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.functions_id_seq OWNER TO postgres;

--
-- Name: functions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.functions_id_seq OWNED BY public.functions.id;


--
-- Name: ministries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ministries (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.ministries OWNER TO postgres;

--
-- Name: ministries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ministries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ministries_id_seq OWNER TO postgres;

--
-- Name: ministries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ministries_id_seq OWNED BY public.ministries.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "scheduleId" integer,
    type public."NotificationType" NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    status public."NotificationStatus" NOT NULL,
    message text,
    error text,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: schedule_member_functions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_member_functions (
    id integer NOT NULL,
    "scheduleMemberId" integer NOT NULL,
    "functionId" integer NOT NULL
);


ALTER TABLE public.schedule_member_functions OWNER TO postgres;

--
-- Name: schedule_member_functions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_member_functions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_member_functions_id_seq OWNER TO postgres;

--
-- Name: schedule_member_functions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_member_functions_id_seq OWNED BY public.schedule_member_functions.id;


--
-- Name: schedule_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_members (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "scheduleId" integer NOT NULL,
    "confirmationStatus" public."ConfirmationStatus" DEFAULT 'PENDING'::public."ConfirmationStatus" NOT NULL,
    "confirmedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.schedule_members OWNER TO postgres;

--
-- Name: schedule_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_members_id_seq OWNER TO postgres;

--
-- Name: schedule_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_members_id_seq OWNED BY public.schedule_members.id;


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedules (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    date timestamp(3) without time zone NOT NULL,
    "time" text NOT NULL,
    location text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.schedules OWNER TO postgres;

--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedules_id_seq OWNER TO postgres;

--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedules_id_seq OWNED BY public.schedules.id;


--
-- Name: unavailabilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unavailabilities (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.unavailabilities OWNER TO postgres;

--
-- Name: unavailabilities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.unavailabilities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unavailabilities_id_seq OWNER TO postgres;

--
-- Name: unavailabilities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.unavailabilities_id_seq OWNED BY public.unavailabilities.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    phone text NOT NULL,
    role public."UserRole" DEFAULT 'MEMBER'::public."UserRole" NOT NULL,
    status public."UserStatus" DEFAULT 'PENDING'::public."UserStatus" NOT NULL,
    "campusId" integer,
    "ministryId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastLogin" timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: campuses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campuses ALTER COLUMN id SET DEFAULT nextval('public.campuses_id_seq'::regclass);


--
-- Name: function_group_admins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_group_admins ALTER COLUMN id SET DEFAULT nextval('public.function_group_admins_id_seq'::regclass);


--
-- Name: function_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_groups ALTER COLUMN id SET DEFAULT nextval('public.function_groups_id_seq'::regclass);


--
-- Name: functions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.functions ALTER COLUMN id SET DEFAULT nextval('public.functions_id_seq'::regclass);


--
-- Name: ministries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ministries ALTER COLUMN id SET DEFAULT nextval('public.ministries_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: schedule_member_functions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_member_functions ALTER COLUMN id SET DEFAULT nextval('public.schedule_member_functions_id_seq'::regclass);


--
-- Name: schedule_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_members ALTER COLUMN id SET DEFAULT nextval('public.schedule_members_id_seq'::regclass);


--
-- Name: schedules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules ALTER COLUMN id SET DEFAULT nextval('public.schedules_id_seq'::regclass);


--
-- Name: unavailabilities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unavailabilities ALTER COLUMN id SET DEFAULT nextval('public.unavailabilities_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d71782aa-2c11-4a4a-ae14-5b9f09fc9f2a	47f9c35b1260af8b73359f790ffc31aea7a44c62798393b93f2e76d88bbfdab4	2025-09-26 12:47:12.020774+00	20250926124711_init	\N	\N	2025-09-26 12:47:11.892512+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, action, "targetId", "userId", description, "createdAt") FROM stdin;
4	FUNCTION_CREATED	13	1	Função "Iluminação" criada no grupo "Sonorização e Iluminação"	2025-09-29 20:11:39.938
5	FUNCTION_CREATED	14	1	Função "Sonorização" criada no grupo "Sonorização e Iluminação"	2025-09-29 20:11:48.797
7	FUNCTION_CREATED	15	1	Função "Ministério de Louvor" criada no grupo "Ministério de Louvor"	2025-09-29 20:13:28.677
9	FUNCTION_CREATED	16	1	Função "Kids" criada no grupo "Kids"	2025-09-30 13:54:23.552
10	MEMBER_APPROVED	8	\N	Membro Ana Márcia foi aprovado	2025-09-30 16:53:50.494
11	MEMBER_APPROVED	19	\N	Membro Marcos Sales foi aprovado	2025-10-01 22:33:50.316
12	MEMBER_APPROVED	18	\N	Membro Ana Dhovana foi aprovado	2025-10-01 22:33:53.604
13	MEMBER_APPROVED	17	\N	Membro Emanoel Lopes foi aprovado	2025-10-01 22:33:56.737
14	MEMBER_APPROVED	16	\N	Membro Maria Vieira foi aprovado	2025-10-01 22:34:09.413
15	MEMBER_APPROVED	15	\N	Membro Quésia Rodrigues foi aprovado	2025-10-01 22:34:15.794
16	MEMBER_APPROVED	14	\N	Membro Ana Ávila foi aprovado	2025-10-01 22:34:18.541
17	MEMBER_APPROVED	13	\N	Membro Amanda Pereira foi aprovado	2025-10-01 22:34:24.813
18	MEMBER_APPROVED	12	\N	Membro Guilherme Dias foi aprovado	2025-10-01 22:34:27.302
19	MEMBER_APPROVED	11	\N	Membro Ana Livia foi aprovado	2025-10-01 22:34:29.824
20	MEMBER_APPROVED	10	\N	Membro Lara Fabian foi aprovado	2025-10-01 22:34:32.291
21	MEMBER_APPROVED	9	\N	Membro Pedro Barros foi aprovado	2025-10-01 22:34:34.872
22	MEMBER_DELETED	7	\N	Membro Rose Dunamys foi excluído do sistema. Campus: Ubajara, Ministério: Ministério Multimídia	2025-10-01 22:36:17.051
23	MEMBER_APPROVED	20	\N	Membro Rose Prado foi aprovado	2025-10-01 22:40:47.411
24	MEMBER_DELETED	6	\N	Membro Pedro Oliveira foi excluído do sistema. Campus: Ubajara, Ministério: Voluntariado Geral	2025-10-01 22:42:44.882
25	MEMBER_DELETED	4	\N	Membro Ana Costa foi excluído do sistema. Campus: Tianguá, Ministério: Ministério Multimídia	2025-10-01 22:42:55.341
26	MEMBER_DELETED	3	\N	Membro Maria Santos foi excluído do sistema. Campus: Tianguá, Ministério: Ministério Multimídia	2025-10-01 22:43:02.917
27	MEMBER_DELETED	5	\N	Membro João Silva foi excluído do sistema. Campus: Ubajara, Ministério: Ministério de Louvor	2025-10-01 22:43:10.382
28	SCHEDULE_DELETED	2	1	Escala "Culto Dominical - Manhã" foi removida	2025-10-01 22:44:11.557
29	SCHEDULE_DELETED	1	1	Escala "Culto Dominical - Manhã" foi removida	2025-10-01 22:44:15.74
30	SCHEDULE_CREATED	3	1	Escala "Teste " criada para 2025-10-02	2025-10-01 23:06:53.367
31	SCHEDULE_NOTIFICATION_SENT	3	1	Notificação customizada (WhatsApp) enviada para escala "Teste "	2025-10-01 23:07:24.42
32	SCHEDULE_CREATED	4	1	Escala "Teste" criada para 2025-11-02	2025-10-02 17:46:43.522
33	SCHEDULE_NOTIFICATION_SENT	3	1	Notificação customizada (WhatsApp) enviada para escala "Teste "	2025-10-02 17:47:15.334
34	SCHEDULE_CREATED	5	1	Escala "Teste" criada para 2025-10-04	2025-10-02 18:25:20.954
35	SCHEDULE_NOTIFICATION_SENT	5	1	Notificação customizada (WhatsApp) enviada para escala "Teste"	2025-10-02 18:25:44.453
36	SCHEDULE_NOTIFICATION_SENT	5	1	Notificação customizada (WhatsApp) enviada para escala "Teste"	2025-10-02 18:49:25.762
37	SCHEDULE_NOTIFICATION_SENT	5	1	Notificação customizada (WhatsApp) enviada para escala "Teste"	2025-10-02 21:51:19.185
\.


--
-- Data for Name: campuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campuses (id, name, city, active, "createdAt", "updatedAt") FROM stdin;
1	Ubajara	Ubajara	t	2025-09-26 12:48:44.004	2025-09-26 12:48:44.004
2	Tianguá	Tianguá	t	2025-09-26 12:48:44.012	2025-09-26 12:48:44.012
\.


--
-- Data for Name: function_group_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.function_group_admins (id, "userId", "functionGroupId", "createdAt", "updatedAt") FROM stdin;
3	20	2	2025-10-01 22:41:10.109	2025-10-01 22:41:10.109
\.


--
-- Data for Name: function_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.function_groups (id, name, description, active, "createdAt", "updatedAt", "ministryId") FROM stdin;
1	Voluntariado Geral	Funções gerais de apoio aos cultos e eventos	t	2025-09-26 12:48:44.035	2025-09-30 16:26:34.648	3
2	Multimídia	Funções relacionadas à produção audiovisual	t	2025-09-26 12:48:44.041	2025-09-30 16:26:34.655	1
4	Ministério de Louvor		t	2025-09-29 20:13:09.499	2025-09-30 16:26:34.658	2
3	Sonorização e Iluminação		t	2025-09-29 20:10:26.431	2025-09-30 16:26:34.66	6
5	Kids		t	2025-09-30 13:54:05.699	2025-09-30 16:26:34.662	8
\.


--
-- Data for Name: functions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.functions (id, name, description, icon, active, "groupId", "createdAt", "updatedAt") FROM stdin;
1	Estacionamento	Organização do estacionamento	car	t	1	2025-09-26 12:48:44.047	2025-09-26 12:48:44.047
2	Acolhimento	Recepção e acolhimento dos visitantes	heart	t	1	2025-09-26 12:48:44.057	2025-09-26 12:48:44.057
3	Auditório	Organização do auditório	users	t	1	2025-09-26 12:48:44.062	2025-09-26 12:48:44.062
4	Dízimos e Oferta	Coleta de dízimos e ofertas	dollar-sign	t	1	2025-09-26 12:48:44.066	2025-09-26 12:48:44.066
5	Comunhão	Organização da comunhão	coffee	t	1	2025-09-26 12:48:44.071	2025-09-26 12:48:44.071
6	Ceia	Organização da santa ceia	utensils	t	1	2025-09-26 12:48:44.075	2025-09-26 12:48:44.075
7	Stories	Criação de stories para redes sociais	instagram	t	2	2025-09-26 12:48:44.081	2025-09-26 12:48:44.081
8	Projeção	Operação do sistema de projeção	projector	t	2	2025-09-26 12:48:44.084	2025-09-26 12:48:44.084
9	Fotos	Fotografia dos eventos	camera	t	2	2025-09-26 12:48:44.087	2025-09-26 12:48:44.087
10	Reels	Criação de reels para redes sociais	video	t	2	2025-09-26 12:48:44.09	2025-09-26 12:48:44.09
11	Live	Transmissão ao vivo	radio	t	2	2025-09-26 12:48:44.093	2025-09-26 12:48:44.093
12	Vídeo Live	Produção de vídeo para transmissão	video	t	2	2025-09-26 12:48:44.095	2025-09-26 12:48:44.095
13	Iluminação	Organizar o sistema de iluminação da igreja	briefcase	t	3	2025-09-29 20:11:39.932	2025-09-29 20:11:39.932
14	Sonorização		briefcase	t	3	2025-09-29 20:11:48.794	2025-09-29 20:11:48.794
15	Ministério de Louvor		briefcase	t	4	2025-09-29 20:13:28.673	2025-09-29 20:13:28.673
16	Kids		users	t	5	2025-09-30 13:54:23.547	2025-09-30 13:54:23.547
17	Voluntariado Kids	Trabalho com crianças no ministério infantil	users	t	5	2025-09-30 14:10:12.314	2025-09-30 14:10:12.314
\.


--
-- Data for Name: ministries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ministries (id, name, description, active, "createdAt", "updatedAt") FROM stdin;
2	Ministério de Louvor	Responsável pela música e adoração nos cultos	t	2025-09-26 12:48:44.024	2025-09-26 12:48:44.024
3	Voluntariado Geral	Atividades gerais de apoio e suporte	t	2025-09-26 12:48:44.027	2025-09-26 12:48:44.027
6	Sonorização e Iluminação	\N	t	2025-09-29 20:10:10.365	2025-09-29 20:10:10.365
1	Ministério Multimídia	Responsável pela transmissão, gravação e equipamentos audiovisuais	t	2025-09-26 12:48:44.017	2025-09-29 20:14:51.487
7	Kids	Ministério de Kids	t	2025-09-30 13:54:05.693	2025-09-30 13:54:05.693
8	Ministério Infantil	Trabalho com crianças e adolescentes	t	2025-09-30 14:10:12.227	2025-09-30 14:10:12.227
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, "userId", "scheduleId", type, channel, status, message, error, "sentAt") FROM stdin;
1	8	3	SCHEDULE_ASSIGNMENT	WHATSAPP	SENT	\N	\N	2025-10-01 23:06:53.377
2	8	3	CUSTOM_NOTIFICATION	WHATSAPP	SENT	teste...	\N	2025-10-01 23:07:24.422
3	8	4	SCHEDULE_ASSIGNMENT	WHATSAPP	SENT	\N	\N	2025-10-02 17:46:43.532
4	8	3	CUSTOM_NOTIFICATION	WHATSAPP	SENT	oi	\N	2025-10-02 17:47:15.335
5	8	5	SCHEDULE_ASSIGNMENT	WHATSAPP	SENT	\N	\N	2025-10-02 18:25:20.965
6	8	5	CUSTOM_NOTIFICATION	WHATSAPP	SENT	teste	\N	2025-10-02 18:25:44.454
7	8	5	CUSTOM_NOTIFICATION	WHATSAPP	SENT	teste	\N	2025-10-02 18:49:25.762
8	8	5	CUSTOM_NOTIFICATION	WHATSAPP	SENT	teste	\N	2025-10-02 21:51:19.191
\.


--
-- Data for Name: schedule_member_functions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_member_functions (id, "scheduleMemberId", "functionId") FROM stdin;
7	5	11
8	6	10
9	7	10
\.


--
-- Data for Name: schedule_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_members (id, "userId", "scheduleId", "confirmationStatus", "confirmedAt", "createdAt", "updatedAt") FROM stdin;
5	8	3	CONFIRMED	2025-10-01 23:54:29.862	2025-10-01 23:06:53.351	2025-10-01 23:54:29.862
6	8	4	PENDING	\N	2025-10-02 17:46:43.497	2025-10-02 17:46:43.497
7	8	5	PENDING	\N	2025-10-02 18:25:20.933	2025-10-02 18:25:20.933
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedules (id, title, description, date, "time", location, "createdAt", "updatedAt") FROM stdin;
3	Teste 	Descrição Teste	2025-10-02 00:00:00	06:00	Ubajara	2025-10-01 23:06:53.351	2025-10-01 23:06:53.351
4	Teste	Teste	2025-11-02 00:00:00	06:45	Ubajara	2025-10-02 17:46:43.497	2025-10-02 17:46:43.497
5	Teste	teste	2025-10-04 00:00:00	06:00	Tianguá	2025-10-02 18:25:20.933	2025-10-02 18:25:20.933
\.


--
-- Data for Name: unavailabilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unavailabilities (id, "userId", "startDate", "endDate", reason, "createdAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, password, phone, role, status, "campusId", "ministryId", "createdAt", "updatedAt", "lastLogin") FROM stdin;
2	Administrador	admin@igreja.com	$2a$12$19kXWVDN0JLJv5FGymvjUerRqQhHZGwUyhZ/ag7DKfmaVeopMseXq	11888888888	ADMIN	ACTIVE	1	1	2025-09-26 12:48:44.772	2025-09-26 21:30:18.299	2025-09-26 21:30:18.298
11	Ana Livia	analivialucasp@gmail.com	$2a$12$KRkmZYq2Q0yuIyAdyd02Nu6Fw1GShLQEFsER38esY23JudsVsSciC	88997512177	MEMBER	ACTIVE	1	1	2025-10-01 22:27:13.757	2025-10-01 22:35:44.248	\N
10	Lara Fabian	larafabiandamasceno@gmail.com	$2a$12$rS8ZCcgK1IITyqywKHXvIOO6rCfv3VcZxSbLfoOfWNXLZ2EViNzYa	88993346775	MEMBER	ACTIVE	1	1	2025-10-01 22:26:23.841	2025-10-01 22:35:49.99	\N
20	Rose Prado	rosepradooliveira5@gmail.com	$2a$12$M5kjCdgisKSYJr4cucdzIOqlu/VUrUE9tkFNuFwFByV5U4wp.n9E2	88999031329	MEMBER	ACTIVE	1	1	2025-10-01 22:39:54.283	2025-10-01 22:44:56.309	2025-10-01 22:44:56.308
19	Marcos Sales	marcos.tiangua14@gmail.com	$2a$12$KCIWefoj5Y1xUFhN3QBNyOWPWU53bxFnQT6uw4V/Qv3IG2qJv4OD.	88993543247	MEMBER	ACTIVE	2	1	2025-10-01 22:32:24.953	2025-10-01 22:34:44.431	\N
18	Ana Dhovana	anadhovana@gmail.com	$2a$12$oPFRMorXOLy3S3vkoJnSmOHXFeI1Eb9rNc782nlQCMOx1LHJBVLH.	88993005574	MEMBER	ACTIVE	2	1	2025-10-01 22:31:13.327	2025-10-01 22:34:50.337	\N
17	Emanoel Lopes	emanoellopes210400@gmail.com	$2a$12$fgN55oljW3mSepc1c0whu.HXWtzS891Szyc1a1H66NMzFkEpIjsH6	85989592262	MEMBER	ACTIVE	2	1	2025-10-01 22:30:50.616	2025-10-01 22:34:58.473	\N
16	Maria Vieira	maariavieira2707@gmail.com	$2a$12$Up1EclwN1Hbv79HplgubRerrXUDHcqPfnoqSdc0BvwTjNszwpbH7W	8899228467	MEMBER	ACTIVE	2	1	2025-10-01 22:30:33.536	2025-10-01 22:35:03.809	\N
15	Quésia Rodrigues	quesiiaaraujo@gmail.com	$2a$12$oBJsczIn3TnYcMiPPjekteGPsQusXAHiQgQH/QuDWcalaK0Gl/Mq2	88988557530	MEMBER	ACTIVE	1	1	2025-10-01 22:30:04.326	2025-10-01 22:35:08.86	\N
14	Ana Ávila	anaavilaenfer@gmail.com	$2a$12$1fmc6GH4nSrhHW331e1olObVoaUk1vJdKvvqoVGUF0pv11QbqQJnW	85991184688	MEMBER	ACTIVE	2	1	2025-10-01 22:29:05.016	2025-10-01 22:35:16.736	\N
13	Amanda Pereira	amandasantos@faculdadeibiapaba.com.br	$2a$12$GFcmq3MZCotmALX3Z24BUuzTDzD94rVpd8RKejTRCQrQYobeR6AjC	88996153201	MEMBER	ACTIVE	2	1	2025-10-01 22:28:41.314	2025-10-01 22:35:23.426	\N
12	Guilherme Dias	guilhermebdiass@gmail.com	$2a$12$dDNQNigayek7RD8edUsY4.l0TydbrWNuNQDR3nZEpeprSQGO5Ubv6	88999668677	MEMBER	ACTIVE	2	1	2025-10-01 22:28:08.276	2025-10-01 22:35:29.759	\N
9	Pedro Barros	pedrotijava.2015@gmail.com	$2a$12$RRUz2PUBEKoEjZvwi/sSTOJAaPzG.bz32Gphz0CCE8PK9b.lcGTQy	88996933210	MEMBER	ACTIVE	1	1	2025-10-01 22:26:00.31	2025-10-01 22:35:38.074	\N
8	Ana Márcia	anamarciaoliveira744@gmail.com	$2a$12$638q5JDyNA4kpmNJleGOKOsSD48l5mATekvLjmWYhxqB1HaFWKO2.	88994054607	MEMBER	ACTIVE	1	1	2025-09-30 14:30:30.8	2025-10-01 23:54:21.104	2025-10-01 23:54:21.103
1	Mathaus Carvalho	mathauscarvalho@gmail.com	$2a$12$G6Bk0tCgrJljECDmrW9adeWM31jClK4bP5sGO0ibH/q6lnWv54QVC	11999999999	ADMIN	ACTIVE	1	1	2025-09-26 12:48:44.443	2025-10-02 18:05:34.485	2025-10-02 18:05:34.483
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 37, true);


--
-- Name: campuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campuses_id_seq', 2, true);


--
-- Name: function_group_admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.function_group_admins_id_seq', 3, true);


--
-- Name: function_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.function_groups_id_seq', 30, true);


--
-- Name: functions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.functions_id_seq', 17, true);


--
-- Name: ministries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ministries_id_seq', 8, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 8, true);


--
-- Name: schedule_member_functions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_member_functions_id_seq', 9, true);


--
-- Name: schedule_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_members_id_seq', 7, true);


--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedules_id_seq', 5, true);


--
-- Name: unavailabilities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.unavailabilities_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 20, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: campuses campuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campuses
    ADD CONSTRAINT campuses_pkey PRIMARY KEY (id);


--
-- Name: function_group_admins function_group_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_group_admins
    ADD CONSTRAINT function_group_admins_pkey PRIMARY KEY (id);


--
-- Name: function_groups function_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_groups
    ADD CONSTRAINT function_groups_pkey PRIMARY KEY (id);


--
-- Name: functions functions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.functions
    ADD CONSTRAINT functions_pkey PRIMARY KEY (id);


--
-- Name: ministries ministries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT ministries_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: schedule_member_functions schedule_member_functions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_member_functions
    ADD CONSTRAINT schedule_member_functions_pkey PRIMARY KEY (id);


--
-- Name: schedule_members schedule_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_members
    ADD CONSTRAINT schedule_members_pkey PRIMARY KEY (id);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: unavailabilities unavailabilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unavailabilities
    ADD CONSTRAINT unavailabilities_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: campuses_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX campuses_name_key ON public.campuses USING btree (name);


--
-- Name: function_group_admins_userId_functionGroupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "function_group_admins_userId_functionGroupId_key" ON public.function_group_admins USING btree ("userId", "functionGroupId");


--
-- Name: function_groups_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX function_groups_name_key ON public.function_groups USING btree (name);


--
-- Name: functions_name_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "functions_name_groupId_key" ON public.functions USING btree (name, "groupId");


--
-- Name: ministries_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ministries_name_key ON public.ministries USING btree (name);


--
-- Name: schedule_member_functions_scheduleMemberId_functionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "schedule_member_functions_scheduleMemberId_functionId_key" ON public.schedule_member_functions USING btree ("scheduleMemberId", "functionId");


--
-- Name: schedule_members_userId_scheduleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "schedule_members_userId_scheduleId_key" ON public.schedule_members USING btree ("userId", "scheduleId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: function_group_admins function_group_admins_functionGroupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_group_admins
    ADD CONSTRAINT "function_group_admins_functionGroupId_fkey" FOREIGN KEY ("functionGroupId") REFERENCES public.function_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: function_group_admins function_group_admins_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_group_admins
    ADD CONSTRAINT "function_group_admins_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: function_groups function_groups_ministryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.function_groups
    ADD CONSTRAINT function_groups_ministryid_fkey FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON DELETE CASCADE;


--
-- Name: functions functions_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.functions
    ADD CONSTRAINT "functions_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.function_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_scheduleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_scheduleId_fkey" FOREIGN KEY ("scheduleId") REFERENCES public.schedules(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: schedule_member_functions schedule_member_functions_functionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_member_functions
    ADD CONSTRAINT "schedule_member_functions_functionId_fkey" FOREIGN KEY ("functionId") REFERENCES public.functions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: schedule_member_functions schedule_member_functions_scheduleMemberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_member_functions
    ADD CONSTRAINT "schedule_member_functions_scheduleMemberId_fkey" FOREIGN KEY ("scheduleMemberId") REFERENCES public.schedule_members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: schedule_members schedule_members_scheduleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_members
    ADD CONSTRAINT "schedule_members_scheduleId_fkey" FOREIGN KEY ("scheduleId") REFERENCES public.schedules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: schedule_members schedule_members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_members
    ADD CONSTRAINT "schedule_members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: unavailabilities unavailabilities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unavailabilities
    ADD CONSTRAINT "unavailabilities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_campusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_campusId_fkey" FOREIGN KEY ("campusId") REFERENCES public.campuses(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict FnAQRsImaNaFpgJLFaSZqpcTgXeeLoWrufDDxkrbhhwqzV65ZLQPjkL9PUARds2

